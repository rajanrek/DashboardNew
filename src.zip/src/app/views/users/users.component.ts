
import {UsersService} from './users.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  public users;
  public userdata;
  public warn;
  constructor(private access: UsersService, public router: Router) {
    console.log('users::constructor');
    
  } 

  ngOnInit() {
    this.listuser();
  }

  deleteUser(id) {
    this.warn = confirm("Are you sure you want to Permanently delete this user?");
    if(this.warn==true){
    this.access.deleteUser(id)
      .subscribe((data => {
        console.log(data, "success")
        error => console.log('error', error)
        // this.router.navigate(['/users']);
        this.listuser();
      }))
    }else{
      this.listuser();
    }
  }
  listuser(){
    this.access.getUsers().subscribe((data => {
      this.userdata = data;
      this.users = this.userdata.Users;
      console.log("checking users data:", this.users);
    }))
  }
}
