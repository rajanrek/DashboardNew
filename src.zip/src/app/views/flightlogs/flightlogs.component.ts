import { Component, OnInit } from '@angular/core';
import { FlightlogsService } from './flightlogs.service';

@Component({
  selector: 'app-flightlogs',
  templateUrl: './flightlogs.component.html',
  styleUrls: ['./flightlogs.component.scss']
})
export class FlightlogsComponent implements OnInit {

  public flights;
   public flightdata;
   public warn;
    constructor(private access:FlightlogsService) { 

  }

  ngOnInit() {

    this.listFlight(); 
  }

  deleteFlight(id) {
    this.warn = confirm("Are you sure you want to Permanently delete this user?");
    if(this.warn==true){
      this.access.deleteFlight(id)
      .subscribe((data => {
        console.log(data, "success")
        error => console.log('error', error)
       this.listFlight();
      }))
    }else{
      this.listFlight(); 
    }
          
  }
  listFlight(){
    this.access.getFlights().subscribe((data => {
      this.flightdata = data;    
      this.flights=this.flightdata.Flights;
       console.log(this.flights);
    }))
  }

}
