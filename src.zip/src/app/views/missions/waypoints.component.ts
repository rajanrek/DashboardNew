import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waypoints',
  templateUrl: './waypoints.component.html',
})
export class WaypointsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
