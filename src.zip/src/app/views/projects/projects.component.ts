import { Component} from '@angular/core';
import { ProjectsService } from './projects.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.scss']
})
export class ProjectsComponent  {
  public projects 
  public id: any;
  public warn;
  constructor(private access: ProjectsService, public router: Router) {
    console.log('Organizations::constructor');
    this.listProject()
  }
  deleteProject(id) {
    this.warn = confirm("Are you sure you want to Permanently delete this Project?");
    if(this.warn==true){
    this.access.deleteProject(id)
      .subscribe((data => {
        console.log(data, "success")
        error => console.log('error', error)
        this.router.navigate(['/project']);
        this.listProject();
      }))
    }else{
      this.listProject();
    }
  }
  listProject(){
    this.access.getProjects().subscribe((data => {
      this.projects = data;    
       console.log(this.projects);
    }))
  }

}
